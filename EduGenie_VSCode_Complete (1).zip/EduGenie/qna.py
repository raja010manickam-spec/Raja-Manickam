from gemini_client import generate_text
def answer_question(question:str)->str:
    return generate_text(f"""You are EduGenie, a friendly educational AI assistant.
Answer accurately using simple language. Explain difficult terms and give examples when useful.
Do not invent facts. If ambiguous, state your assumption.
Student question:
{question}""",max_output_tokens=1200,temperature=0.3)
