from gemini_client import generate_text
def get_learning_recommendations(topic):
    return generate_text(f"""Create a practical beginner-to-advanced learning path for {topic}.
For each stage include concepts, exercises, resource types, estimated time, and expected outcome.
End with a weekly routine, revision strategy, self-assessment checklist, and next steps.
Do not invent specific URLs.""",max_output_tokens=2000,temperature=0.4)
