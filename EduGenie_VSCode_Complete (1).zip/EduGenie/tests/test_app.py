from fastapi.testclient import TestClient
import main
client=TestClient(main.app)

def test_health():
    r=client.get("/health"); assert r.status_code==200; assert r.json()["status"]=="ok"

def test_home():
    r=client.get("/"); assert r.status_code==200; assert "EduGenie" in r.text

def test_qa(monkeypatch):
    monkeypatch.setattr(main,"answer_question",lambda x:"Mock answer")
    r=client.post("/qa",json={"text":"test"}); assert r.status_code==200; assert r.json()["result"]=="Mock answer"

def test_explain(monkeypatch):
    monkeypatch.setattr(main,"explain_concept",lambda x:"Mock explanation")
    r=client.post("/explain",json={"text":"test"}); assert r.status_code==200

def test_quiz(monkeypatch):
    q=[{"question":"2+2?","options":["1","2","3","4"],"answer":"4"}]
    monkeypatch.setattr(main,"generate_quiz",lambda x:q)
    r=client.post("/quiz",json={"text":"math"}); assert r.status_code==200; assert r.json()["result"]==q

def test_summary(monkeypatch):
    monkeypatch.setattr(main,"summarize_text",lambda x:"summary")
    r=client.post("/summarize",json={"text":"text"}); assert r.status_code==200

def test_learning(monkeypatch):
    monkeypatch.setattr(main,"get_learning_recommendations",lambda x:"path")
    r=client.post("/learn/recommendations",json={"text":"Python"}); assert r.status_code==200
