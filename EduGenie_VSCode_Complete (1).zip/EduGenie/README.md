# EduGenie - Google Gemini Powered Learning Assistant

Complete FastAPI + HTML/CSS/JavaScript project based on the supplied EduGenie project documentation.

## Features
- Question & Answer
- Concept Explanation
- Quiz generation: 3 MCQs, 4 options each
- Summarization
- Beginner-to-advanced learning paths

## Setup

### Windows PowerShell
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and set `GEMINI_API_KEY`.

Run:
```powershell
uvicorn main:app --reload
```

Open:
http://127.0.0.1:8000

API docs:
http://127.0.0.1:8000/docs

Tests:
```powershell
pytest -q
```

Do not commit `.env`.
