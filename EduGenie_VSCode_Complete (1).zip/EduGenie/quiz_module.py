import json,re
from gemini_client import generate_text

def clean_json_block(text):
    text=text.strip()
    text=re.sub(r"^```(?:json)?\s*","",text,flags=re.I)
    text=re.sub(r"\s*```$","",text)
    return text.strip()

def validate_quiz(data):
    if not isinstance(data,list) or len(data)!=3: raise ValueError("Quiz must contain exactly 3 questions.")
    out=[]
    for i,item in enumerate(data,1):
        if not isinstance(item,dict): raise ValueError(f"Question {i} is invalid.")
        q=str(item.get("question","")).strip(); opts=item.get("options"); ans=str(item.get("answer","")).strip()
        if not q or not isinstance(opts,list) or len(opts)!=4 or not ans or ans not in opts:
            raise ValueError(f"Question {i} must have a question, 4 options and a valid answer.")
        out.append({"question":q,"options":[str(x).strip() for x in opts],"answer":ans})
    return out

def generate_quiz(passage):
    raw=generate_text(f"""Create exactly 3 multiple-choice questions from this educational passage.
Each has exactly 4 plausible options and one correct answer. Return ONLY valid JSON, no Markdown.
Format:
[{{"question":"...","options":["A","B","C","D"],"answer":"Exact option"}}]
Passage:
{passage}""",max_output_tokens=1800,temperature=0.2)
    try: return validate_quiz(json.loads(clean_json_block(raw)))
    except Exception as e: raise RuntimeError(f"Quiz generation/parsing failed: {e}") from e
