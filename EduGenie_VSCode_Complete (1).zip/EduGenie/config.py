import os
from dotenv import load_dotenv
load_dotenv()
GEMINI_API_KEY=os.getenv("GEMINI_API_KEY","").strip()
GEMINI_MODEL=os.getenv("GEMINI_MODEL","gemini-3.8-flash").strip()
LOCAL_EXPLAINER_ENABLED=os.getenv("LOCAL_EXPLAINER_ENABLED","false").lower()=="true"
LOCAL_EXPLAINER_MODEL=os.getenv("LOCAL_EXPLAINER_MODEL","MBZUAI/LaMini-Flan-T5-783M").strip()
MAX_OUTPUT_TOKENS=int(os.getenv("MAX_OUTPUT_TOKENS","1200"))
TEMPERATURE=float(os.getenv("TEMPERATURE","0.4"))
