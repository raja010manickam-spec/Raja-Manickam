from config import LOCAL_EXPLAINER_ENABLED,LOCAL_EXPLAINER_MODEL
from gemini_client import generate_text
_local_pipeline=None

def _local_explain(topic):
    global _local_pipeline
    if _local_pipeline is None:
        from transformers import pipeline
        _local_pipeline=pipeline("text2text-generation",model=LOCAL_EXPLAINER_MODEL,device=-1)
    prompt=f"Explain {topic} to a beginner. Give a simple definition, how it works, an example, and a key takeaway."
    return _local_pipeline(prompt,max_new_tokens=220,do_sample=False)[0]["generated_text"].strip()

def explain_concept(topic):
    if LOCAL_EXPLAINER_ENABLED:
        try: return _local_explain(topic)
        except Exception: pass
    return generate_text(f"""You are EduGenie, an expert teacher.
Explain this concept to a beginner using:
1. Simple definition
2. How it works
3. Easy real-world example
4. Important points
5. Key takeaway
Concept:
{topic}""",max_output_tokens=1200,temperature=0.3)
