from functools import lru_cache
from google import genai
from google.genai import types
from config import GEMINI_API_KEY,GEMINI_MODEL,MAX_OUTPUT_TOKENS,TEMPERATURE

@lru_cache(maxsize=1)
def get_client():
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is not configured. Create .env and add your Gemini API key.")
    return genai.Client(api_key=GEMINI_API_KEY)

def generate_text(prompt:str,*,max_output_tokens:int|None=None,temperature:float|None=None)->str:
    response=get_client().models.generate_content(
        model=GEMINI_MODEL,contents=prompt,
        config=types.GenerateContentConfig(
            temperature=TEMPERATURE if temperature is None else temperature,
            max_output_tokens=MAX_OUTPUT_TOKENS if max_output_tokens is None else max_output_tokens))
    text=(response.text or "").strip()
    if not text: raise RuntimeError("Gemini returned an empty response.")
    return text
