from gemini_client import generate_text
def summarize_text(text):
    return generate_text(f"""Summarize this educational text for quick revision.
Keep important facts, remove repetition, use simple language, and do not add information.
Text:
{text}""",max_output_tokens=1400,temperature=0.3)
